import { useState, useEffect } from 'react'
import { Download, Filter } from 'lucide-react'
import { supabase } from '@/lib/supabase'
import { 
  BarChart, 
  Bar, 
  LineChart,
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  ScatterChart,
  Scatter,
  ReferenceLine
} from 'recharts'

const chartTypes = [
  { id: 'pareto', name: 'Pareto' },
  { id: 'xbar-r', name: 'X-bar/R' },
  { id: 'fishbone', name: 'Fishbone' },
  { id: 'histogram', name: 'Histogram' },
  { id: 'scatter', name: 'Scatter' },
  { id: 'p-chart', name: 'P-Chart' },
  { id: 'c-chart', name: 'C-Chart' },
]

export default function QCCharts() {
  const [activeChart, setActiveChart] = useState('pareto')
  const [qcData, setQcData] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchQCData()
  }, [])

  const fetchQCData = async () => {
    try {
      const { data } = await supabase
        .from('qc_charts_data')
        .select('*')
        .order('created_at', { ascending: false })

      setQcData(data || [])
    } catch (error) {
      console.error('Error fetching QC data:', error)
    } finally {
      setLoading(false)
    }
  }

  const getParetoData = () => [
    { defect: 'Packaging Seal Failure', count: 180, cumulative: 41.9 },
    { defect: 'Raw Milk Temp Deviation', count: 110, cumulative: 67.4 },
    { defect: 'Off-flavor', count: 70, cumulative: 83.7 },
    { defect: 'Fill Weight', count: 40, cumulative: 93.0 },
    { defect: 'Contamination', count: 30, cumulative: 100.0 },
  ]

  const getControlChartData = () => {
    const mean = 6.8
    const ucl = 7.0
    const lcl = 6.6
    const data = []
    
    for (let i = 1; i <= 20; i++) {
      const variation = (Math.random() - 0.5) * 0.3
      data.push({
        sample: i,
        value: mean + variation,
        ucl,
        lcl,
        mean,
      })
    }
    return data
  }

  const getHistogramData = () => [
    { range: '2.0-2.5', count: 5 },
    { range: '2.5-3.0', count: 15 },
    { range: '3.0-3.5', count: 45 },
    { range: '3.5-4.0', count: 65 },
    { range: '4.0-4.5', count: 45 },
    { range: '4.5-5.0', count: 20 },
    { range: '5.0+', count: 5 },
  ]

  const getScatterData = () => {
    const data = []
    for (let i = 0; i < 50; i++) {
      const temp = 4 + Math.random() * 6
      const bacteria = temp * 15000 + (Math.random() - 0.5) * 20000
      data.push({ temperature: temp, bacteria })
    }
    return data
  }

  const getPChartData = () => {
    const p = 0.05
    const n = 100
    const ucl = p + 3 * Math.sqrt(p * (1 - p) / n)
    const lcl = Math.max(0, p - 3 * Math.sqrt(p * (1 - p) / n))
    
    return Array.from({ length: 20 }, (_, i) => ({
      sample: i + 1,
      proportion: p + (Math.random() - 0.5) * 0.03,
      ucl,
      lcl,
      centerLine: p,
    }))
  }

  const getCChartData = () => {
    const c = 8
    const ucl = c + 3 * Math.sqrt(c)
    const lcl = Math.max(0, c - 3 * Math.sqrt(c))
    
    return Array.from({ length: 20 }, (_, i) => ({
      sample: i + 1,
      defects: c + Math.floor((Math.random() - 0.5) * 6),
      ucl,
      lcl,
      centerLine: c,
    }))
  }

  const renderChart = () => {
    switch (activeChart) {
      case 'pareto':
        return (
          <div>
            <div className="mb-32">
              <h3 className="text-title font-semibold text-neutral-900 mb-16">Pareto Analysis</h3>
              <p className="text-body text-neutral-700">
                Identifies the most significant defect types following the 80/20 rule
              </p>
            </div>
            <ResponsiveContainer width="100%" height={500}>
              <BarChart data={getParetoData()}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E5E5E5" />
                <XAxis 
                  dataKey="defect" 
                  stroke="#A3A3A3"
                  angle={-15}
                  textAnchor="end"
                  height={100}
                  style={{ fontSize: '14px' }}
                />
                <YAxis 
                  yAxisId="left"
                  stroke="#A3A3A3"
                  style={{ fontSize: '14px' }}
                  label={{ value: 'Count', angle: -90, position: 'insideLeft' }}
                />
                <YAxis 
                  yAxisId="right"
                  orientation="right"
                  stroke="#A3A3A3"
                  style={{ fontSize: '14px' }}
                  label={{ value: 'Cumulative %', angle: 90, position: 'insideRight' }}
                />
                <Tooltip 
                  contentStyle={{
                    backgroundColor: 'white',
                    border: '1px solid #E5E5E5',
                    borderRadius: '12px',
                  }}
                />
                <Legend />
                <Bar yAxisId="left" dataKey="count" fill="#0066FF" name="Defect Count" />
                <Line 
                  yAxisId="right" 
                  type="monotone" 
                  dataKey="cumulative" 
                  stroke="#EF4444" 
                  strokeWidth={3}
                  name="Cumulative %"
                  dot={{ fill: '#EF4444', r: 5 }}
                />
                <ReferenceLine yAxisId="right" y={80} stroke="#10B981" strokeDasharray="5 5" label="80%" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )

      case 'xbar-r':
        return (
          <div>
            <div className="mb-32">
              <h3 className="text-title font-semibold text-neutral-900 mb-16">X-bar Control Chart</h3>
              <p className="text-body text-neutral-700">
                Monitors process mean with upper and lower control limits (pH values)
              </p>
            </div>
            <ResponsiveContainer width="100%" height={500}>
              <LineChart data={getControlChartData()}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E5E5E5" />
                <XAxis 
                  dataKey="sample" 
                  stroke="#A3A3A3"
                  label={{ value: 'Sample Number', position: 'insideBottom', offset: -5 }}
                  style={{ fontSize: '14px' }}
                />
                <YAxis 
                  stroke="#A3A3A3"
                  domain={[6.4, 7.2]}
                  style={{ fontSize: '14px' }}
                  label={{ value: 'pH Value', angle: -90, position: 'insideLeft' }}
                />
                <Tooltip 
                  contentStyle={{
                    backgroundColor: 'white',
                    border: '1px solid #E5E5E5',
                    borderRadius: '12px',
                  }}
                />
                <Legend />
                <Line 
                  type="monotone" 
                  dataKey="ucl" 
                  stroke="#EF4444" 
                  strokeDasharray="5 5"
                  strokeWidth={2}
                  name="UCL (Upper Control Limit)"
                  dot={false}
                />
                <Line 
                  type="monotone" 
                  dataKey="mean" 
                  stroke="#10B981" 
                  strokeDasharray="3 3"
                  strokeWidth={2}
                  name="Mean"
                  dot={false}
                />
                <Line 
                  type="monotone" 
                  dataKey="lcl" 
                  stroke="#EF4444" 
                  strokeDasharray="5 5"
                  strokeWidth={2}
                  name="LCL (Lower Control Limit)"
                  dot={false}
                />
                <Line 
                  type="monotone" 
                  dataKey="value" 
                  stroke="#0066FF" 
                  strokeWidth={3}
                  name="Measured Value"
                  dot={{ fill: '#0066FF', r: 5 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        )

      case 'fishbone':
        return (
          <div>
            <div className="mb-32">
              <h3 className="text-title font-semibold text-neutral-900 mb-16">Fishbone Diagram</h3>
              <p className="text-body text-neutral-700">
                Root cause analysis using the 6M categories (Methods, Materials, Machines, Manpower, Measurement, Environment)
              </p>
            </div>
            <div className="bg-white rounded-lg p-48 border border-neutral-200">
              <div className="text-center mb-48">
                <div className="inline-block bg-critical-500/10 border-2 border-critical-500 rounded-lg px-32 py-16">
                  <p className="text-title font-bold text-critical-700">Milk Quality Issue</p>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-48">
                <div className="space-y-24">
                  <div className="border-l-4 border-primary pl-24">
                    <h4 className="text-body font-semibold text-neutral-900 mb-8">Methods</h4>
                    <ul className="text-small text-neutral-700 space-y-4">
                      <li>• Inconsistent pasteurization time</li>
                      <li>• Variable cooling procedures</li>
                    </ul>
                  </div>
                  <div className="border-l-4 border-primary pl-24">
                    <h4 className="text-body font-semibold text-neutral-900 mb-8">Materials</h4>
                    <ul className="text-small text-neutral-700 space-y-4">
                      <li>• Raw milk quality variation</li>
                      <li>• Contaminated packaging</li>
                    </ul>
                  </div>
                  <div className="border-l-4 border-primary pl-24">
                    <h4 className="text-body font-semibold text-neutral-900 mb-8">Machines</h4>
                    <ul className="text-small text-neutral-700 space-y-4">
                      <li>• Equipment calibration drift</li>
                      <li>• Insufficient cleaning cycles</li>
                    </ul>
                  </div>
                </div>
                
                <div className="space-y-24">
                  <div className="border-l-4 border-primary pl-24">
                    <h4 className="text-body font-semibold text-neutral-900 mb-8">Manpower</h4>
                    <ul className="text-small text-neutral-700 space-y-4">
                      <li>• Inadequate training</li>
                      <li>• Shift communication gaps</li>
                    </ul>
                  </div>
                  <div className="border-l-4 border-primary pl-24">
                    <h4 className="text-body font-semibold text-neutral-900 mb-8">Measurement</h4>
                    <ul className="text-small text-neutral-700 space-y-4">
                      <li>• Sensor accuracy degradation</li>
                      <li>• Inconsistent sampling</li>
                    </ul>
                  </div>
                  <div className="border-l-4 border-primary pl-24">
                    <h4 className="text-body font-semibold text-neutral-900 mb-8">Environment</h4>
                    <ul className="text-small text-neutral-700 space-y-4">
                      <li>• Temperature fluctuations</li>
                      <li>• Humidity control issues</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )

      case 'histogram':
        return (
          <div>
            <div className="mb-32">
              <h3 className="text-title font-semibold text-neutral-900 mb-16">Histogram - Fat Content Distribution</h3>
              <p className="text-body text-neutral-700">
                Shows the frequency distribution of fat content percentage
              </p>
            </div>
            <ResponsiveContainer width="100%" height={500}>
              <BarChart data={getHistogramData()}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E5E5E5" />
                <XAxis 
                  dataKey="range" 
                  stroke="#A3A3A3"
                  label={{ value: 'Fat Content (%)', position: 'insideBottom', offset: -5 }}
                  style={{ fontSize: '14px' }}
                />
                <YAxis 
                  stroke="#A3A3A3"
                  label={{ value: 'Frequency', angle: -90, position: 'insideLeft' }}
                  style={{ fontSize: '14px' }}
                />
                <Tooltip 
                  contentStyle={{
                    backgroundColor: 'white',
                    border: '1px solid #E5E5E5',
                    borderRadius: '12px',
                  }}
                />
                <Bar dataKey="count" fill="#10B981" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )

      case 'scatter':
        return (
          <div>
            <div className="mb-32">
              <h3 className="text-title font-semibold text-neutral-900 mb-16">Scatter Plot - Temperature vs Bacteria Count</h3>
              <p className="text-body text-neutral-700">
                Correlation analysis between storage temperature and microbial growth
              </p>
            </div>
            <ResponsiveContainer width="100%" height={500}>
              <ScatterChart>
                <CartesianGrid strokeDasharray="3 3" stroke="#E5E5E5" />
                <XAxis 
                  type="number" 
                  dataKey="temperature" 
                  name="Temperature"
                  stroke="#A3A3A3"
                  label={{ value: 'Temperature (°C)', position: 'insideBottom', offset: -5 }}
                  style={{ fontSize: '14px' }}
                />
                <YAxis 
                  type="number" 
                  dataKey="bacteria" 
                  name="Bacteria"
                  stroke="#A3A3A3"
                  label={{ value: 'Bacteria Count (CFU/ml)', angle: -90, position: 'insideLeft' }}
                  style={{ fontSize: '14px' }}
                />
                <Tooltip 
                  cursor={{ strokeDasharray: '3 3' }}
                  contentStyle={{
                    backgroundColor: 'white',
                    border: '1px solid #E5E5E5',
                    borderRadius: '12px',
                  }}
                />
                <Scatter name="Samples" data={getScatterData()} fill="#0066FF" />
              </ScatterChart>
            </ResponsiveContainer>
          </div>
        )

      case 'p-chart':
        return (
          <div>
            <div className="mb-32">
              <h3 className="text-title font-semibold text-neutral-900 mb-16">P-Chart - Proportion Defective</h3>
              <p className="text-body text-neutral-700">
                Tracks the proportion of defective units in each sample
              </p>
            </div>
            <ResponsiveContainer width="100%" height={500}>
              <LineChart data={getPChartData()}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E5E5E5" />
                <XAxis 
                  dataKey="sample" 
                  stroke="#A3A3A3"
                  label={{ value: 'Sample Number', position: 'insideBottom', offset: -5 }}
                  style={{ fontSize: '14px' }}
                />
                <YAxis 
                  stroke="#A3A3A3"
                  label={{ value: 'Proportion Defective', angle: -90, position: 'insideLeft' }}
                  style={{ fontSize: '14px' }}
                />
                <Tooltip 
                  contentStyle={{
                    backgroundColor: 'white',
                    border: '1px solid #E5E5E5',
                    borderRadius: '12px',
                  }}
                />
                <Legend />
                <Line type="monotone" dataKey="ucl" stroke="#EF4444" strokeDasharray="5 5" name="UCL" dot={false} />
                <Line type="monotone" dataKey="centerLine" stroke="#10B981" strokeDasharray="3 3" name="Center Line" dot={false} />
                <Line type="monotone" dataKey="lcl" stroke="#EF4444" strokeDasharray="5 5" name="LCL" dot={false} />
                <Line 
                  type="monotone" 
                  dataKey="proportion" 
                  stroke="#0066FF" 
                  strokeWidth={3}
                  name="Proportion"
                  dot={{ fill: '#0066FF', r: 5 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        )

      case 'c-chart':
        return (
          <div>
            <div className="mb-32">
              <h3 className="text-title font-semibold text-neutral-900 mb-16">C-Chart - Defects Per Unit</h3>
              <p className="text-body text-neutral-700">
                Monitors the count of defects per inspection unit
              </p>
            </div>
            <ResponsiveContainer width="100%" height={500}>
              <LineChart data={getCChartData()}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E5E5E5" />
                <XAxis 
                  dataKey="sample" 
                  stroke="#A3A3A3"
                  label={{ value: 'Sample Number', position: 'insideBottom', offset: -5 }}
                  style={{ fontSize: '14px' }}
                />
                <YAxis 
                  stroke="#A3A3A3"
                  label={{ value: 'Number of Defects', angle: -90, position: 'insideLeft' }}
                  style={{ fontSize: '14px' }}
                />
                <Tooltip 
                  contentStyle={{
                    backgroundColor: 'white',
                    border: '1px solid #E5E5E5',
                    borderRadius: '12px',
                  }}
                />
                <Legend />
                <Line type="monotone" dataKey="ucl" stroke="#EF4444" strokeDasharray="5 5" name="UCL" dot={false} />
                <Line type="monotone" dataKey="centerLine" stroke="#10B981" strokeDasharray="3 3" name="Center Line" dot={false} />
                <Line type="monotone" dataKey="lcl" stroke="#EF4444" strokeDasharray="5 5" name="LCL" dot={false} />
                <Line 
                  type="monotone" 
                  dataKey="defects" 
                  stroke="#0066FF" 
                  strokeWidth={3}
                  name="Defect Count"
                  dot={{ fill: '#0066FF', r: 5 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        )

      default:
        return null
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[600px]">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-primary border-t-transparent"></div>
      </div>
    )
  }

  return (
    <div>
      {/* Page Header */}
      <section className="bg-background-page py-64 px-32">
        <div className="container mx-auto max-w-7xl">
          <div className="mb-16">
            <p className="text-small text-neutral-500">Dashboard / QC Charts</p>
          </div>
          <h1 className="text-title-large font-bold text-neutral-900 mb-24">
            Quality Control Charts
          </h1>
          <p className="text-body-large text-neutral-700 max-w-3xl">
            Interactive dashboard with 7 statistical process control charts for comprehensive quality analysis
          </p>
        </div>
      </section>

      {/* Chart Display Area */}
      <section className="py-64 px-32 bg-background-surface">
        <div className="container mx-auto max-w-7xl">
          {/* Tab Navigation */}
          <div className="flex flex-wrap gap-8 mb-32 border-b border-neutral-200">
            {chartTypes.map((chart) => (
              <button
                key={chart.id}
                onClick={() => setActiveChart(chart.id)}
                className={`px-24 py-12 text-body font-medium transition-all duration-base rounded-t-md ${
                  activeChart === chart.id
                    ? 'bg-primary text-white'
                    : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
                }`}
              >
                {chart.name}
              </button>
            ))}
          </div>

          {/* Control Toolbar */}
          <div className="flex items-center gap-16 mb-32 p-16 bg-neutral-100 rounded-md border border-neutral-200">
            <button className="flex items-center gap-2 px-16 py-8 bg-white border border-neutral-200 rounded-md hover:bg-neutral-50 transition-colors">
              <Filter className="h-4 w-4 text-neutral-700" />
              <span className="text-small text-neutral-700">Filter</span>
            </button>
            <button className="flex items-center gap-2 px-16 py-8 bg-white border border-neutral-200 rounded-md hover:bg-neutral-50 transition-colors">
              <Download className="h-4 w-4 text-neutral-700" />
              <span className="text-small text-neutral-700">Export PDF</span>
            </button>
            <button className="flex items-center gap-2 px-16 py-8 bg-white border border-neutral-200 rounded-md hover:bg-neutral-50 transition-colors">
              <Download className="h-4 w-4 text-neutral-700" />
              <span className="text-small text-neutral-700">Export CSV</span>
            </button>
          </div>

          {/* Chart Canvas */}
          <div className="bg-white rounded-lg p-48 shadow-card border border-neutral-200">
            {renderChart()}
          </div>
        </div>
      </section>
    </div>
  )
}
