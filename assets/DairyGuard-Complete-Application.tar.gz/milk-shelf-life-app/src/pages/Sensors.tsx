import { useEffect, useState } from 'react'
import { Thermometer, Droplets, Activity, Wifi, WifiOff, AlertCircle } from 'lucide-react'
import { supabase } from '@/lib/supabase'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'

interface Sensor {
  id: string
  sensor_id: string
  sensor_type: string
  location: string
  status: string
  last_reading: string
  accuracy: number
  range_min: number
  range_max: number
}

interface SensorReading {
  value: number
  timestamp: string
  sensor_type: string
}

export default function Sensors() {
  const [sensors, setSensors] = useState<Sensor[]>([])
  const [readings, setReadings] = useState<SensorReading[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchSensors()
    fetchRecentReadings()

    // Subscribe to real-time sensor updates
    const channel = supabase
      .channel('sensors-updates')
      .on('postgres_changes', { 
        event: '*', 
        schema: 'public', 
        table: 'sensor_readings' 
      }, () => {
        fetchRecentReadings()
      })
      .subscribe()

    // Poll for updates every 5 seconds
    const interval = setInterval(() => {
      fetchRecentReadings()
    }, 5000)

    return () => {
      supabase.removeChannel(channel)
      clearInterval(interval)
    }
  }, [])

  const fetchSensors = async () => {
    try {
      const { data, error } = await supabase
        .from('sensors')
        .select('*')
        .order('sensor_type')

      if (error) throw error
      setSensors(data || [])
    } catch (error) {
      console.error('Error fetching sensors:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchRecentReadings = async () => {
    try {
      const { data, error } = await supabase
        .from('sensor_readings')
        .select('value, timestamp, sensor_id')
        .order('timestamp', { ascending: false })
        .limit(100)

      if (error) throw error

      // Get sensor types
      const { data: sensorsData } = await supabase
        .from('sensors')
        .select('id, sensor_type')

      const sensorMap = new Map(sensorsData?.map(s => [s.id, s.sensor_type]) || [])

      const readingsWithType = (data || []).map(r => ({
        value: r.value,
        timestamp: r.timestamp,
        sensor_type: sensorMap.get(r.sensor_id) || 'Unknown',
      }))

      setReadings(readingsWithType)
    } catch (error) {
      console.error('Error fetching readings:', error)
    }
  }

  const getSensorIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case 'temperature':
        return Thermometer
      case 'ph':
        return Droplets
      case 'bacteria':
        return Activity
      default:
        return AlertCircle
    }
  }

  const getSensorStatus = (lastReading: string) => {
    const lastUpdate = new Date(lastReading)
    const now = new Date()
    const diffMinutes = (now.getTime() - lastUpdate.getTime()) / (1000 * 60)

    if (diffMinutes < 5) return 'active'
    if (diffMinutes < 15) return 'warning'
    return 'offline'
  }

  const SensorCard = ({ sensor }: { sensor: Sensor }) => {
    const Icon = getSensorIcon(sensor.sensor_type)
    const status = getSensorStatus(sensor.last_reading)

    const statusConfig = {
      active: {
        color: 'text-success-500',
        bg: 'bg-success-500/10',
        border: 'border-success-500',
        pulse: true,
      },
      warning: {
        color: 'text-warning-500',
        bg: 'bg-warning-500/10',
        border: 'border-warning-500',
        pulse: false,
      },
      offline: {
        color: 'text-neutral-500',
        bg: 'bg-neutral-500/10',
        border: 'border-neutral-500',
        pulse: false,
      },
    }

    const config = statusConfig[status as keyof typeof statusConfig]

    // Get latest reading for this sensor
    const latestReading = readings.find(r => r.sensor_type === sensor.sensor_type)

    return (
      <div className={`bg-background-surface rounded-lg p-48 shadow-card border-l-4 ${config.border} relative`}>
        {/* Connection Status Indicator */}
        <div className="absolute top-4 right-4">
          {status === 'active' ? (
            <div className="relative">
              <div className={`h-3 w-3 rounded-full ${config.bg} border-2 ${config.border} ${config.pulse ? 'animate-pulse' : ''}`} />
              <Wifi className={`h-5 w-5 ${config.color} absolute -top-1 -right-6`} />
            </div>
          ) : (
            <WifiOff className="h-5 w-5 text-neutral-500" />
          )}
        </div>

        <Icon className={`h-8 w-8 mb-16 ${config.color}`} />
        <h3 className="text-title font-semibold text-neutral-900 mb-16">{sensor.sensor_type}</h3>
        
        {latestReading && (
          <>
            <div className="mb-24">
              <span className="text-hero font-bold text-neutral-900">{latestReading.value.toFixed(2)}</span>
              <span className="text-body text-neutral-700 ml-2">
                {sensor.sensor_type === 'Temperature' ? '°C' : sensor.sensor_type === 'pH' ? 'pH' : 'CFU/ml'}
              </span>
            </div>
          </>
        )}

        <div className="space-y-8 mb-24">
          <p className="text-caption text-neutral-500">
            Accuracy: ±{sensor.accuracy}
            {sensor.sensor_type === 'Temperature' ? '°C' : sensor.sensor_type === 'pH' ? ' pH' : ''}
          </p>
          <p className="text-caption text-neutral-500">
            Range: {sensor.range_min} - {sensor.range_max}
          </p>
          <p className="text-caption text-neutral-500">
            Location: {sensor.location || 'Not specified'}
          </p>
        </div>

        <p className="text-caption text-neutral-500">
          Last updated: {new Date(sensor.last_reading).toLocaleString()}
        </p>
      </div>
    )
  }

  const getChartData = () => {
    // Group readings by timestamp and sensor type
    const grouped = readings.reduce((acc, reading) => {
      const time = new Date(reading.timestamp).toLocaleTimeString()
      const existing = acc.find(item => item.time === time)
      
      if (existing) {
        existing[reading.sensor_type] = reading.value
      } else {
        acc.push({
          time,
          [reading.sensor_type]: reading.value,
        })
      }
      
      return acc
    }, [] as any[])

    return grouped.slice(0, 20).reverse()
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[600px]">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-primary border-t-transparent"></div>
      </div>
    )
  }

  return (
    <div>
      {/* Page Header */}
      <section className="bg-background-page py-64 px-32">
        <div className="container mx-auto max-w-7xl">
          <div className="mb-16">
            <p className="text-small text-neutral-500">Dashboard / Sensors</p>
          </div>
          <h1 className="text-title-large font-bold text-neutral-900 mb-24">
            Real-Time Sensor Monitoring
          </h1>
          <p className="text-body-large text-neutral-700 max-w-3xl">
            Live IoT sensor data dashboard with connectivity status and current readings from dairy monitoring system
          </p>
        </div>
      </section>

      {/* Sensor Status Grid */}
      <section className="py-64 px-32 bg-background-surface">
        <div className="container mx-auto max-w-7xl">
          <h2 className="text-title font-semibold text-neutral-900 mb-48">Active Sensors</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-24">
            {sensors.map((sensor) => (
              <SensorCard key={sensor.id} sensor={sensor} />
            ))}
          </div>
        </div>
      </section>

      {/* Live Data Chart */}
      <section className="py-64 px-32 bg-background-page">
        <div className="container mx-auto max-w-7xl">
          <h2 className="text-title font-semibold text-neutral-900 mb-48">Live Sensor Data</h2>
          <div className="bg-white rounded-lg p-48 shadow-card">
            <ResponsiveContainer width="100%" height={500}>
              <LineChart data={getChartData()}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E5E5E5" />
                <XAxis 
                  dataKey="time" 
                  stroke="#A3A3A3"
                  style={{ fontSize: '14px' }}
                />
                <YAxis 
                  stroke="#A3A3A3"
                  style={{ fontSize: '14px' }}
                />
                <Tooltip 
                  contentStyle={{
                    backgroundColor: 'white',
                    border: '1px solid #E5E5E5',
                    borderRadius: '12px',
                    boxShadow: '0 1px 3px rgba(0, 0, 0, 0.1)',
                  }}
                />
                <Legend 
                  wrapperStyle={{ fontSize: '14px' }}
                />
                <Line 
                  type="monotone" 
                  dataKey="Temperature" 
                  stroke="#0066FF" 
                  strokeWidth={2}
                  dot={{ fill: '#0066FF', r: 4 }}
                  activeDot={{ r: 6 }}
                />
                <Line 
                  type="monotone" 
                  dataKey="pH" 
                  stroke="#10B981" 
                  strokeWidth={2}
                  dot={{ fill: '#10B981', r: 4 }}
                  activeDot={{ r: 6 }}
                />
                <Line 
                  type="monotone" 
                  dataKey="Bacteria" 
                  stroke="#F59E0B" 
                  strokeWidth={2}
                  dot={{ fill: '#F59E0B', r: 4 }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </section>

      {/* Sensor Specifications Table */}
      <section className="py-64 px-32 bg-background-surface">
        <div className="container mx-auto max-w-7xl">
          <h2 className="text-title font-semibold text-neutral-900 mb-48">Sensor Specifications</h2>
          <div className="bg-white rounded-lg shadow-card overflow-hidden">
            <table className="w-full">
              <thead className="bg-neutral-100">
                <tr>
                  <th className="px-24 py-16 text-left text-small font-semibold text-neutral-900">Sensor Type</th>
                  <th className="px-24 py-16 text-left text-small font-semibold text-neutral-900">Accuracy</th>
                  <th className="px-24 py-16 text-left text-small font-semibold text-neutral-900">Range</th>
                  <th className="px-24 py-16 text-left text-small font-semibold text-neutral-900">Location</th>
                  <th className="px-24 py-16 text-left text-small font-semibold text-neutral-900">Status</th>
                </tr>
              </thead>
              <tbody>
                {sensors.map((sensor, idx) => (
                  <tr key={sensor.id} className={idx % 2 === 0 ? 'bg-white' : 'bg-neutral-50'}>
                    <td className="px-24 py-16 text-body text-neutral-900">{sensor.sensor_type}</td>
                    <td className="px-24 py-16 text-body text-neutral-700">±{sensor.accuracy}</td>
                    <td className="px-24 py-16 text-body text-neutral-700">
                      {sensor.range_min} - {sensor.range_max}
                    </td>
                    <td className="px-24 py-16 text-body text-neutral-700">{sensor.location || 'N/A'}</td>
                    <td className="px-24 py-16">
                      <span className={`inline-flex items-center px-12 py-4 rounded-full text-caption font-medium ${
                        sensor.status === 'active' 
                          ? 'bg-success-500/10 text-success-700' 
                          : 'bg-neutral-500/10 text-neutral-700'
                      }`}>
                        {sensor.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>
    </div>
  )
}
