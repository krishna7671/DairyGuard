import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import Dashboard from './pages/Dashboard'
import Sensors from './pages/Sensors'
import Prediction from './pages/Prediction'
import QCCharts from './pages/QCCharts'
import Alerts from './pages/Alerts'
import Analytics from './pages/Analytics'
import AddProduct from './pages/AddProduct'
import './index.css'

function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/sensors" element={<Sensors />} />
          <Route path="/prediction" element={<Prediction />} />
          <Route path="/qc-charts" element={<QCCharts />} />
          <Route path="/alerts" element={<Alerts />} />
          <Route path="/analytics" element={<Analytics />} />
          <Route path="/add-product" element={<AddProduct />} />
        </Routes>
      </Layout>
    </Router>
  )
}

export default App
