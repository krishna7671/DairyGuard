import { useEffect, useState } from 'react'
import { TrendingUp, Download, Calendar } from 'lucide-react'
import { supabase } from '@/lib/supabase'
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'

interface AnalyticsData {
  shelfLifeTrend: any[]
  predictionAccuracy: any[]
  batchComparison: any[]
  sensorDrift: any[]
}

export default function Analytics() {
  const [data, setData] = useState<AnalyticsData>({
    shelfLifeTrend: [],
    predictionAccuracy: [],
    batchComparison: [],
    sensorDrift: [],
  })
  const [loading, setLoading] = useState(true)
  const [dateRange, setDateRange] = useState('30')

  useEffect(() => {
    fetchAnalytics()
  }, [dateRange])

  const fetchAnalytics = async () => {
    try {
      // Fetch shelf life predictions trend
      const { data: predictions } = await supabase
        .from('shelf_life_predictions')
        .select('*')
        .order('last_updated', { ascending: false })
        .limit(30)

      const shelfLifeTrend = predictions?.map(p => ({
        date: new Date(p.last_updated).toLocaleDateString(),
        predicted: p.predicted_shelf_life_hours / 24,
        accuracy: p.accuracy_score,
      })).reverse() || []

      // Generate mock data for batch comparison
      const batchComparison = [
        { type: 'Whole Milk', avgShelfLife: 5.2, samples: 45 },
        { type: '2% Milk', avgShelfLife: 5.8, samples: 38 },
        { type: 'Fat-Free', avgShelfLife: 6.5, samples: 32 },
        { type: 'Organic', avgShelfLife: 4.9, samples: 28 },
      ]

      // Generate prediction accuracy trend
      const predictionAccuracy = Array.from({ length: 12 }, (_, i) => ({
        month: new Date(2025, i, 1).toLocaleDateString('en-US', { month: 'short' }),
        accuracy: 88 + Math.random() * 8,
        r2: 0.92 + Math.random() * 0.06,
      }))

      // Generate sensor drift data
      const sensorDrift = Array.from({ length: 30 }, (_, i) => ({
        day: i + 1,
        temperature: 0.1 + (Math.random() - 0.5) * 0.3,
        ph: 0.05 + (Math.random() - 0.5) * 0.1,
        bacteria: 0.15 + (Math.random() - 0.5) * 0.2,
      }))

      setData({
        shelfLifeTrend,
        predictionAccuracy,
        batchComparison,
        sensorDrift,
      })
    } catch (error) {
      console.error('Error fetching analytics:', error)
    } finally {
      setLoading(false)
    }
  }

  const exportData = (format: 'pdf' | 'csv') => {
    console.log(`Exporting data as ${format}`)
    // Implementation would integrate with a PDF/CSV generation library
    alert(`Export as ${format.toUpperCase()} feature will be implemented`)
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[600px]">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-primary border-t-transparent"></div>
      </div>
    )
  }

  return (
    <div>
      {/* Page Header */}
      <section className="bg-background-page py-64 px-32">
        <div className="container mx-auto max-w-7xl">
          <div className="mb-16">
            <p className="text-small text-neutral-500">Dashboard / Analytics</p>
          </div>
          <div className="flex items-start justify-between">
            <div>
              <h1 className="text-title-large font-bold text-neutral-900 mb-24">
                Historical Analytics & Trends
              </h1>
              <p className="text-body-large text-neutral-700 max-w-3xl">
                Comprehensive trend analysis, performance metrics, and long-term insights for dairy quality monitoring
              </p>
            </div>

            {/* Date Range Picker */}
            <div className="flex items-center gap-2 bg-white rounded-md shadow-card p-4">
              <Calendar className="h-5 w-5 text-neutral-700" />
              <select
                value={dateRange}
                onChange={(e) => setDateRange(e.target.value)}
                className="px-12 py-8 bg-transparent text-small text-neutral-900 outline-none"
              >
                <option value="7">Last 7 days</option>
                <option value="30">Last 30 days</option>
                <option value="90">Last 90 days</option>
                <option value="365">Last year</option>
              </select>
            </div>
          </div>
        </div>
      </section>

      {/* KPI Summary Cards */}
      <section className="py-64 px-32 bg-background-surface">
        <div className="container mx-auto max-w-7xl">
          <h2 className="text-title font-semibold text-neutral-900 mb-48">Performance Summary</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-24">
            <div className="bg-white rounded-lg p-32 shadow-card">
              <TrendingUp className="h-8 w-8 text-success-500 mb-16" />
              <p className="text-small text-neutral-700 mb-8">Avg Prediction Accuracy</p>
              <p className="text-title-large font-bold text-neutral-900">94.2%</p>
              <p className="text-caption text-success-700 mt-8">+2.3% vs last month</p>
            </div>

            <div className="bg-white rounded-lg p-32 shadow-card">
              <TrendingUp className="h-8 w-8 text-primary mb-16" />
              <p className="text-small text-neutral-700 mb-8">R² Score</p>
              <p className="text-title-large font-bold text-neutral-900">0.96</p>
              <p className="text-caption text-neutral-500 mt-8">Model fit quality</p>
            </div>

            <div className="bg-white rounded-lg p-32 shadow-card">
              <TrendingUp className="h-8 w-8 text-success-500 mb-16" />
              <p className="text-small text-neutral-700 mb-8">Avg Shelf Life</p>
              <p className="text-title-large font-bold text-neutral-900">5.6 days</p>
              <p className="text-caption text-success-700 mt-8">+0.4 days improvement</p>
            </div>

            <div className="bg-white rounded-lg p-32 shadow-card">
              <TrendingUp className="h-8 w-8 text-warning-500 mb-16" />
              <p className="text-small text-neutral-700 mb-8">Quality Alerts</p>
              <p className="text-title-large font-bold text-neutral-900">12</p>
              <p className="text-caption text-warning-700 mt-8">-5 vs last month</p>
            </div>
          </div>
        </div>
      </section>

      {/* Shelf Life Trend Analysis */}
      <section className="py-64 px-32 bg-background-page">
        <div className="container mx-auto max-w-7xl">
          <div className="flex items-center justify-between mb-48">
            <h2 className="text-title font-semibold text-neutral-900">Shelf Life Trends</h2>
            <div className="flex gap-2">
              <button
                onClick={() => exportData('pdf')}
                className="flex items-center gap-2 px-16 py-8 bg-white border border-neutral-200 rounded-md hover:bg-neutral-50 transition-colors"
              >
                <Download className="h-4 w-4 text-neutral-700" />
                <span className="text-small text-neutral-700">Export PDF</span>
              </button>
              <button
                onClick={() => exportData('csv')}
                className="flex items-center gap-2 px-16 py-8 bg-white border border-neutral-200 rounded-md hover:bg-neutral-50 transition-colors"
              >
                <Download className="h-4 w-4 text-neutral-700" />
                <span className="text-small text-neutral-700">Export CSV</span>
              </button>
            </div>
          </div>

          <div className="bg-white rounded-lg p-48 shadow-card">
            <ResponsiveContainer width="100%" height={400}>
              <LineChart data={data.shelfLifeTrend}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E5E5E5" />
                <XAxis 
                  dataKey="date" 
                  stroke="#A3A3A3"
                  style={{ fontSize: '14px' }}
                />
                <YAxis 
                  stroke="#A3A3A3"
                  style={{ fontSize: '14px' }}
                  label={{ value: 'Shelf Life (days)', angle: -90, position: 'insideLeft' }}
                />
                <Tooltip 
                  contentStyle={{
                    backgroundColor: 'white',
                    border: '1px solid #E5E5E5',
                    borderRadius: '12px',
                  }}
                />
                <Legend />
                <Line 
                  type="monotone" 
                  dataKey="predicted" 
                  stroke="#0066FF" 
                  strokeWidth={3}
                  name="Predicted Shelf Life"
                  dot={{ fill: '#0066FF', r: 4 }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </section>

      {/* Batch Comparison */}
      <section className="py-64 px-32 bg-background-surface">
        <div className="container mx-auto max-w-7xl">
          <h2 className="text-title font-semibold text-neutral-900 mb-48">Batch Comparison Analysis</h2>
          <div className="bg-white rounded-lg p-48 shadow-card">
            <ResponsiveContainer width="100%" height={400}>
              <BarChart data={data.batchComparison}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E5E5E5" />
                <XAxis 
                  dataKey="type" 
                  stroke="#A3A3A3"
                  style={{ fontSize: '14px' }}
                />
                <YAxis 
                  stroke="#A3A3A3"
                  style={{ fontSize: '14px' }}
                  label={{ value: 'Avg Shelf Life (days)', angle: -90, position: 'insideLeft' }}
                />
                <Tooltip 
                  contentStyle={{
                    backgroundColor: 'white',
                    border: '1px solid #E5E5E5',
                    borderRadius: '12px',
                  }}
                />
                <Legend />
                <Bar 
                  dataKey="avgShelfLife" 
                  fill="#10B981" 
                  name="Average Shelf Life"
                  radius={[8, 8, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </section>

      {/* Model Performance Over Time */}
      <section className="py-64 px-32 bg-background-page">
        <div className="container mx-auto max-w-7xl">
          <h2 className="text-title font-semibold text-neutral-900 mb-48">Model Performance Over Time</h2>
          <div className="bg-white rounded-lg p-48 shadow-card">
            <ResponsiveContainer width="100%" height={400}>
              <LineChart data={data.predictionAccuracy}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E5E5E5" />
                <XAxis 
                  dataKey="month" 
                  stroke="#A3A3A3"
                  style={{ fontSize: '14px' }}
                />
                <YAxis 
                  yAxisId="left"
                  stroke="#A3A3A3"
                  style={{ fontSize: '14px' }}
                  domain={[85, 100]}
                  label={{ value: 'Accuracy (%)', angle: -90, position: 'insideLeft' }}
                />
                <YAxis 
                  yAxisId="right"
                  orientation="right"
                  stroke="#A3A3A3"
                  style={{ fontSize: '14px' }}
                  domain={[0.9, 1.0]}
                  label={{ value: 'R² Score', angle: 90, position: 'insideRight' }}
                />
                <Tooltip 
                  contentStyle={{
                    backgroundColor: 'white',
                    border: '1px solid #E5E5E5',
                    borderRadius: '12px',
                  }}
                />
                <Legend />
                <Line 
                  yAxisId="left"
                  type="monotone" 
                  dataKey="accuracy" 
                  stroke="#0066FF" 
                  strokeWidth={3}
                  name="Accuracy (%)"
                  dot={{ fill: '#0066FF', r: 4 }}
                />
                <Line 
                  yAxisId="right"
                  type="monotone" 
                  dataKey="r2" 
                  stroke="#10B981" 
                  strokeWidth={3}
                  name="R² Score"
                  dot={{ fill: '#10B981', r: 4 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </section>

      {/* Sensor Drift Patterns */}
      <section className="py-64 px-32 bg-background-surface">
        <div className="container mx-auto max-w-7xl">
          <h2 className="text-title font-semibold text-neutral-900 mb-48">Sensor Drift Patterns</h2>
          <div className="bg-white rounded-lg p-48 shadow-card">
            <ResponsiveContainer width="100%" height={400}>
              <LineChart data={data.sensorDrift}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E5E5E5" />
                <XAxis 
                  dataKey="day" 
                  stroke="#A3A3A3"
                  style={{ fontSize: '14px' }}
                  label={{ value: 'Days', position: 'insideBottom', offset: -5 }}
                />
                <YAxis 
                  stroke="#A3A3A3"
                  style={{ fontSize: '14px' }}
                  label={{ value: 'Drift (units)', angle: -90, position: 'insideLeft' }}
                />
                <Tooltip 
                  contentStyle={{
                    backgroundColor: 'white',
                    border: '1px solid #E5E5E5',
                    borderRadius: '12px',
                  }}
                />
                <Legend />
                <Line 
                  type="monotone" 
                  dataKey="temperature" 
                  stroke="#EF4444" 
                  strokeWidth={2}
                  name="Temperature Drift"
                  dot={false}
                />
                <Line 
                  type="monotone" 
                  dataKey="ph" 
                  stroke="#10B981" 
                  strokeWidth={2}
                  name="pH Drift"
                  dot={false}
                />
                <Line 
                  type="monotone" 
                  dataKey="bacteria" 
                  stroke="#F59E0B" 
                  strokeWidth={2}
                  name="Bacteria Sensor Drift"
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </section>
    </div>
  )
}
